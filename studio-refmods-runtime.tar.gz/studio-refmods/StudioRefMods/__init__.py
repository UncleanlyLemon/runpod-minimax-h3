"""Merge a variable-length character list through the pinned native H3 RefMod loader."""
import json,re
class StudioH3CharacterLoader:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'characters_json':('STRING',{'multiline':True}),'max_total_tokens':('INT',{'default':40000,'min':1,'max':40000})}}
    RETURN_TYPES=('H3_REF_MODS',)
    FUNCTION='load'
    CATEGORY='Studio/Characters'
    @classmethod
    def IS_CHANGED(cls,**kwargs):return float('nan')
    def load(self,characters_json,max_total_tokens=40000):
        import nodes
        if not isinstance(max_total_tokens,int) or not 1<=max_total_tokens<=40000:raise ValueError('Invalid reference token budget')
        entries=json.loads(characters_json)
        if not isinstance(entries,list) or not entries:raise ValueError('Choose at least one character')
        if len(characters_json)>64000:raise ValueError('Character selection is too large')
        mods=[]
        for start in range(0,len(entries),8):
            args={}
            for i in range(1,9):args.update({f'mod_{i}':'(none)',f'strength_{i}':1.0,f'copies_{i}':1,f'components_{i}':'All'})
            for i,item in enumerate(entries[start:start+8],1):
                if not isinstance(item,dict) or not isinstance(item.get('name'),str) or not re.fullmatch(r'studio-cache/[a-f0-9]{64}(?:\.safetensors)?',item['name']) or item.get('components') not in ['All','Visual']:raise ValueError('Invalid character selection')
                args[f'mod_{i}']=item['name'];args[f'components_{i}']=item['components']
            loaded=nodes.NODE_CLASS_MAPPINGS['MiniMaxH3RefModsLoader']().load(show_info=False,max_total_tokens=max_total_tokens,**args)[0]
            mods.extend(loaded)
        total=sum(mod.token_count for mod,strength in mods if strength>0)
        if total>max_total_tokens:raise ValueError(f'Characters use {total} reference tokens; worker limit is {max_total_tokens}. Use fewer views per character or fewer characters for this shot.')
        return (mods,)
NODE_CLASS_MAPPINGS={'StudioH3CharacterLoader':StudioH3CharacterLoader}
NODE_DISPLAY_NAME_MAPPINGS={'StudioH3CharacterLoader':'Studio · Saved characters'}
from .video import StudioH3VideoTextEncode
NODE_CLASS_MAPPINGS['StudioH3VideoTextEncode']=StudioH3VideoTextEncode
NODE_DISPLAY_NAME_MAPPINGS['StudioH3VideoTextEncode']='Studio · Characters + silent blocking video'
from .shot_images import StudioH3ShotImageRefs
NODE_CLASS_MAPPINGS['StudioH3ShotImageRefs']=StudioH3ShotImageRefs
NODE_DISPLAY_NAME_MAPPINGS['StudioH3ShotImageRefs']='Studio · Shot reference images'
