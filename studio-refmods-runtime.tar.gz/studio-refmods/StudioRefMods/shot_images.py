"""Per-shot reference stills appended to the native RefMod conditioning list."""
import importlib


def reference_image_size(width, height):
    if min(width, height) < 32:
        raise ValueError('A reference image must be at least 32 pixels on each side')
    scale = min(1.0, 1024 / max(width, height))
    return tuple(max(32, round(edge * scale / 32) * 32) for edge in (width, height))


class StudioH3ShotImageRefs:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            'required': {'mods': ('H3_REF_MODS',), 'vae': ('VAE',), 'image_1': ('IMAGE',)},
            'optional': {'image_2': ('IMAGE',), 'image_3': ('IMAGE',)},
        }

    RETURN_TYPES = ('H3_REF_MODS',)
    FUNCTION = 'append'
    CATEGORY = 'Studio/References'

    def append(self, mods, vae, image_1, image_2=None, image_3=None):
        import comfy.utils
        import nodes
        import torch
        encoder = nodes.NODE_CLASS_MAPPINGS['MiniMaxH3RefModTextEncode']
        core = importlib.import_module(encoder.__module__.rsplit('.', 1)[0] + '.core')
        combined = list(mods)
        if image_3 is not None and image_2 is None:
            raise ValueError('Shot reference images must be numbered consecutively')
        for index, pixels in enumerate((image_1, image_2, image_3), 1):
            if pixels is None:
                continue
            if pixels.ndim != 4 or pixels.shape[0] != 1 or pixels.shape[-1] != 3:
                raise ValueError('Each shot reference must be one RGB still image')
            _, height, width, _ = pixels.shape
            w, h = reference_image_size(width, height)
            if (w, h) != (width, height):
                pixels = comfy.utils.common_upscale(
                    pixels.movedim(-1, 1), w, h, 'lanczos', 'disabled'
                ).movedim(1, -1)
            latent = vae.encode(pixels).to(torch.float16)
            if latent.ndim != 5 or latent.shape[:3] != (1, 24, 1):
                raise ValueError('Shot reference images require the native H3 video VAE')
            mod = core.H3RefMod(name=f'Reference image {index}', kind='image', latent=latent,
                               latent_t=1, latent_h=latent.shape[3], latent_w=latent.shape[4],
                               mode='encode', source='image', concept_type='generic')
            combined.append((mod, 1.0))
        if sum(m.token_count for m, strength in combined if strength > 0) > 40000:
            raise ValueError('Characters and shot images exceed the reference-token limit. Use fewer images or fewer character views.')
        return (combined,)
