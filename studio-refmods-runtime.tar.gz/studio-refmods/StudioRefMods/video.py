"""Silent video references, using the same native H3 RefMod encoder as characters.

This is conventional Ref2VA reference conditioning, not Code Video Model's
early-step-only sampler. Uploaded soundtracks are deliberately never decoded.
"""
import importlib
import math
import pathlib


def decode_video(path):
    import av
    import numpy as np
    from PIL import Image
    frames=[]
    with av.open(str(path)) as container:
        if not container.streams.video:
            raise ValueError('Blocking file has no video stream')
        stream=container.streams.video[0]
        if not 0 < stream.width <= 4096 or not 0 < stream.height <= 4096:
            raise ValueError('Blocking video dimensions exceed 4096 pixels')
        # Match native H3's 24 fps timeline; cap the reference at 512 short edge
        # to leave reference-token space for the characters and their voices.
        scale=min(1.0,512/min(stream.width,stream.height),896/max(stream.width,stream.height))
        width=max(32,int(stream.width*scale)//32*32)
        height=max(32,int(stream.height*scale)//32*32)
        first=None;last=-1.0;previous=None
        for decoded,frame in enumerate(container.decode(stream)):
            if decoded>=2048:raise ValueError('Blocking video has too many source frames')
            if frame.time is None:raise ValueError('Blocking video requires frame timestamps')
            if first is None:first=float(frame.time)
            time=float(frame.time)-first
            if not math.isfinite(time) or time < last or time > 15.1:
                raise ValueError('Blocking video must be 2–15 seconds with ordered timestamps')
            last=time
            # A slow source frame is held until the next timestamp; do not
            # substitute a future frame for an earlier point on the timeline.
            while previous is not None and len(frames)/24 < time-1e-6:
                frames.append(previous)
                if len(frames)>362:raise ValueError('Blocking video exceeds 15 seconds')
            previous=np.asarray(frame.to_image().convert('RGB').resize((width,height),Image.Resampling.LANCZOS)).copy()
            if len(frames)/24 <= time+1e-6:frames.append(previous)
        if previous is None or len(frames)<48:raise ValueError('Blocking video must contain at least two seconds')
        # Native H3 video encodes use 17n+5 frames. Trim only the small tail;
        # never stretch the blocking action to the requested output duration.
        count=5+17*((len(frames)-5)//17)
        return np.stack(frames[:count]).astype(np.float32)/255


class StudioH3VideoTextEncode:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'clip':('CLIP',),'vae':('VAE',),'mods':('H3_REF_MODS',),
                'video':('STRING',),'prompt':('STRING',{'multiline':True}),
                'reference_fps':('FLOAT',{'default':24.0,'min':24.0,'max':24.0}),
                'max_total_tokens':('INT',{'default':40000,'min':1,'max':40000})}}
    RETURN_TYPES=('CONDITIONING','STRING')
    FUNCTION='encode'
    CATEGORY='Studio/Blocking'

    def encode(self,clip,vae,mods,video,prompt,reference_fps=24.0,max_total_tokens=40000):
        import torch
        import folder_paths
        import nodes
        if reference_fps!=24 or not 1<=max_total_tokens<=40000:raise ValueError('Invalid blocking reference settings')
        # Only the worker's uploaded MP4 may be read, never arbitrary file paths.
        name=pathlib.PurePosixPath(video)
        if name.name!=video or not video.startswith('studio-') or name.suffix.lower()!='.mp4':
            raise ValueError('Invalid uploaded blocking video')
        path=pathlib.Path(folder_paths.get_input_directory())/video
        if not path.is_file() or not 0<path.stat().st_size<=6_000_000:raise ValueError('Invalid blocking video size')
        encoder=nodes.NODE_CLASS_MAPPINGS['MiniMaxH3RefModTextEncode']
        # Import the pinned native pack, not a duplicate or incompatible copy.
        core=importlib.import_module(encoder.__module__.rsplit('.',1)[0]+'.core')
        pixels=decode_video(path)
        latent=vae.encode(torch.from_numpy(pixels))
        if latent.ndim!=5 or latent.shape[0]!=1 or latent.shape[1]!=24:
            raise ValueError('Blocking video requires the native H3 video VAE')
        mod=core.H3RefMod(name='Studio silent blocking',kind='video',latent=latent,
                latent_t=latent.shape[2],latent_h=latent.shape[3],latent_w=latent.shape[4],
                mode='encode',source='video',concept_type='pose_motion')
        combined=list(mods)+[(mod,1.0)]
        total=sum(m.token_count for m,strength in combined if strength>0)
        if total>max_total_tokens:raise ValueError('Blocking video plus characters exceed the reference-token limit. Shorten the reference or use fewer character views.')
        return encoder().encode(clip=clip,mods=combined,prompt=prompt,reference_fps=24.0,
                max_total_tokens=max_total_tokens,vae=vae)
