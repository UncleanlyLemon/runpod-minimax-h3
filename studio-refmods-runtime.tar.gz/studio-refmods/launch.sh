#!/bin/bash
# Endpoint start-command overlay; immutable source bundle is already on its private network volume.
set -euo pipefail
STUDIO_RUNTIME="$(cd -- "$(dirname -- "$0")" && pwd)"
export STUDIO_RUNTIME
python3 - <<'PY'
import os,pathlib,json,hashlib,shutil
root=pathlib.Path(os.environ['STUDIO_RUNTIME'])
pin=json.loads((root/'source-pin.json').read_text())
for file,digest in pin['files'].items():
 if hashlib.sha256((root/file).read_bytes()).hexdigest()!=digest:raise RuntimeError('Studio runtime checksum mismatch')
for base in [pathlib.Path('/opt/comfyui-baked'),pathlib.Path('/workspace/runpod-slim/ComfyUI')]:
 if not (base/'main.py').exists():continue
 target=base/'custom_nodes/ComfyUI-MiniMaxH3Mod'
 if target.exists():
  marker=target/'studio-source-pin.json'
  if not marker.exists() or json.loads(marker.read_text()).get('commit')!=pin['nodeCommit']:raise RuntimeError('Conflicting RefMod node installation')
 else:
  shutil.copytree(root/'ComfyUI-MiniMaxH3Mod',target);(target/'studio-source-pin.json').write_text(json.dumps({'commit':pin['nodeCommit']}))
 studio=base/'custom_nodes/StudioRefMods'
 if not studio.exists():shutil.copytree(root/'StudioRefMods',studio)
 dest=base/'models/refmods';shared=pathlib.Path('/runpod-volume/models/refmods');shared.mkdir(parents=True,exist_ok=True)
 if not dest.exists() and not dest.is_symlink():dest.symlink_to(shared,target_is_directory=True)
handler=pathlib.Path('/opt/serverless/handler.py');source=handler.read_text()
if 'studio_refmod_runtime' not in source:
 anchor='if __name__ == "__main__":'
 if anchor not in source:raise RuntimeError('Unexpected worker handler; refusing to patch')
 handler.with_name('handler-studio-original.py').write_text(source)
 insertion='import sys\nsys.path.insert(0, '+repr(str(root))+')\nfrom studio_refmod_runtime import wrap_handler\nhandler = wrap_handler(handler, globals())\n\n'
 handler.write_text(source.replace(anchor,insertion+anchor))
PY
exec /opt/serverless/entrypoint.sh
