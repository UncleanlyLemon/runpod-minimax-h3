"""Versioned Studio protocol; existing worker requests retain their original handler."""
import asyncio,base64,copy,hashlib,json,pathlib,re,uuid
VERSION=1
MAX_FILE=16_000_000
ALLOWED={'StudioH3CharacterLoader','StudioH3VideoTextEncode','VAELoader','LoadImage','LoadAudio','MiniMaxH3RefModMasterExtract','MiniMaxH3RefModsLoader','MiniMaxH3RefModTextEncode','EmptyMiniMaxH3LatentAV','MiniMaxH3AddGuide','UNETLoader','LoraLoaderModelOnly','ModelAttentionBackend','BlockSparseAttention','CLIPLoader','BasicGuider','RandomNoise','KSamplerSelect','BasicScheduler','ManualSigmas','SamplerCustomAdvanced','VAEDecode','VAEDecodeAudio','VHS_VideoCombine','LoadUpscalerTensorrtModel','UpscalerTensorrt','ImageScale'}
ALLOWED.add('StudioH3ShotImageRefs')

def shot_image_uploads(graph):
    required=set()
    for node in graph.values():
        if node['class_type']!='StudioH3ShotImageRefs':continue
        inputs=node['inputs']
        for field in ('image_1','image_2','image_3'):
            if field not in inputs and field!='image_1':continue
            link=inputs.get(field)
            if not isinstance(link,list) or len(link)!=2 or not isinstance(link[0],str) or link[1]!=0 or graph.get(link[0],{}).get('class_type')!='LoadImage':
                raise ValueError('Each shot reference must use an uploaded still image')
            required.add((link[0],'image'))
    return required

def bytes_from(value,limit):
    if not isinstance(value,str) or len(value)>limit*4//3+8:raise ValueError('Upload exceeds file limit')
    data=base64.b64decode(value,validate=True)
    if not data or len(data)>limit:raise ValueError('Invalid upload size')
    return data

def safe_under(root,relative):
    p=pathlib.PurePosixPath(relative)
    if p.is_absolute() or '..' in p.parts or not p.parts:raise ValueError('Invalid artifact path')
    resolved=(root/str(p)).resolve()
    if root.resolve() not in resolved.parents:raise ValueError('Artifact escapes model folder')
    return resolved

def inspect_refmod(path):
    from safetensors import safe_open
    if not path.is_file() or not 8<path.stat().st_size<=MAX_FILE:raise ValueError('Invalid RefMod size')
    with safe_open(str(path),framework='pt',device='cpu') as reader:
        meta=json.loads((reader.metadata() or {}).get('refmod_meta','{}'))
        members=meta.get('members',[]) if meta.get('kind')=='bundle' else [meta]
        if len(members)>2 or sum(m.get('kind') in ['image','video'] for m in members)!=1 or any(m.get('kind') not in ['image','video','audio'] for m in members):raise ValueError('Expected appearance RefMod with optional voice')
        if len(list(reader.keys()))!=len(members):raise ValueError('RefMod tensor layout mismatch')
    return meta

def wrap_handler(original,env):
    async def handler(job):
        inp=job.get('input') or {}
        if 'studio_refmod_version' not in inp:
            result=await original(job)
            if inp.get('action')=='health' and isinstance(result,dict):result['studio_refmod_version']=VERSION;result['studio_video_version']=1;result['studio_shot_image_refs_version']=1
            return result
        if inp.get('studio_refmod_version')!=VERSION:raise ValueError('Unsupported Studio character protocol')
        if inp.get('studio_video_version',1)!=1:raise ValueError('Unsupported Studio blocking protocol')
        if inp.get('operation') not in ['create','render']:raise ValueError('Unknown character operation')
        graph=copy.deepcopy(inp.get('prompt_graph'))
        if not isinstance(graph,dict) or not graph or len(graph)>100:raise ValueError('Invalid character workflow')
        if any(not isinstance(n,dict) or n.get('class_type') not in ALLOWED or not isinstance(n.get('inputs'),dict) for n in graph.values()):raise ValueError('Unsupported character workflow node')
        shot_images=shot_image_uploads(graph)
        files=inp.get('files',[])
        if not isinstance(files,list) or len(files)>256:raise ValueError('Invalid file count')
        await env['_ensure_comfy']()
        info=json.loads(await asyncio.to_thread(env['_http'],'/object_info',None,30))
        missing={n['class_type'] for n in graph.values()}-set(info)
        if missing:raise ValueError('Worker missing character support: '+','.join(sorted(missing)))
        comfy=pathlib.Path(env['COMFY_DIR']);modelroot=comfy/'models/refmods'
        transient_files=[]
        try:
            seen=set()
            for f in files:
                if not isinstance(f,dict):raise ValueError('Invalid file entry')
                if f.get('kind')=='refmod':
                    digest=f.get('sha256','')
                    if not re.fullmatch('[a-f0-9]{64}',digest):raise ValueError('Invalid character hash')
                    raw=bytes_from(f.get('b64'),MAX_FILE)
                    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('Character checksum mismatch')
                    dest=safe_under(modelroot,'studio-cache/'+digest+'.safetensors');dest.parent.mkdir(parents=True,exist_ok=True)
                    if dest.exists():
                        if hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:raise ValueError('Cached character checksum mismatch')
                    else:
                        temp=dest.with_suffix('.'+uuid.uuid4().hex+'.tmp');temp.write_bytes(raw)
                        try:inspect_refmod(temp);temp.replace(dest)
                        finally:temp.unlink(missing_ok=True)
                else:
                    node=f.get('node');field=f.get('field');name=f.get('filename','')
                    if node not in graph or field not in ['image','audio','video'] or (node,field) in seen:raise ValueError('Invalid media binding')
                    expected={'image':'LoadImage','audio':'LoadAudio','video':'StudioH3VideoTextEncode'}[field]
                    if graph[node]['class_type']!=expected or pathlib.Path(name).name!=name:raise ValueError('Media binding mismatch')
                    ext=pathlib.Path(name).suffix.lower()
                    if ext not in (['.png','.jpg','.jpeg','.webp'] if field=='image' else ['.mp4'] if field=='video' else ['.mp3','.wav','.m4a','.flac','.ogg']):raise ValueError('Unsupported input format')
                    data=bytes_from(f.get('b64'),20_000_000 if field=='image' else 6_000_000 if field=='video' else 10_000_000)
                    target=await asyncio.to_thread(env['_upload'],'studio-'+uuid.uuid4().hex+ext,data)
                    graph[node]['inputs'][field]=target;seen.add((node,field))
                    if field=='video' or (node,field) in shot_images:transient_files.append(safe_under(comfy/'input',target))
            if any(n['class_type']=='StudioH3VideoTextEncode' and (key,'video') not in seen for key,n in graph.items()):raise ValueError('Missing blocking video upload')
            if not shot_images.issubset(seen):raise ValueError('Missing shot reference image upload')
            artifact=None
            if inp['operation']=='create':
                raw=inp.get('artifact','')
                if not isinstance(raw,str) or not raw.startswith('studio/') or not raw.endswith('/character.safetensors'):raise ValueError('Invalid creation destination')
                artifact=safe_under(modelroot,raw)
                creators=[n for n in graph.values() if n['class_type']=='MiniMaxH3RefModMasterExtract']
                if len(creators)!=1 or creators[0]['inputs'].get('subfolder')!=str(pathlib.PurePosixPath(raw).parent) or creators[0]['inputs'].get('name')!='character':raise ValueError('Creation destination mismatch')
            # One accepted Comfy prompt only. Cancellation follows original worker semantics.
            try:
                history=await env['_queue_and_wait'](graph)
            except TimeoutError:
                await asyncio.to_thread(env['_http'],'/interrupt',{},5)
                raise
            if artifact is not None:
                meta=await asyncio.to_thread(inspect_refmod,artifact);data=await asyncio.to_thread(artifact.read_bytes)
                return {'studio_refmod_version':VERSION,'refmod':{'filename':'character.safetensors','sha256':hashlib.sha256(data).hexdigest(),'b64':base64.b64encode(data).decode(),'metadata':meta}}
            outputs,texts=await asyncio.to_thread(env['_collect_outputs'],history,graph,job,[0])
            if not outputs:raise RuntimeError('Character workflow produced no video')
            return {'studio_refmod_version':VERSION,'outputs':outputs,'texts':texts}
        finally:
            for path in transient_files:path.unlink(missing_ok=True)
    return handler
